package com.prog.controller;

@Controller

public class EmpController {
	
	@Autowired
	private Empservice service;
	
	public String home()
	{
		return "index";
	}
	
	@GetMapping("/addemp")
	public String addEmpForm()
	{
		return "add_emp";
	}
	
	@PostMapping("/register")
	public String empRegister(@ModelAttribute Employee e,HttpSession session) {
		
		System.out.println(e);
		
		service.addEmp (e);
		
		Session.setAttribute("msg", "Employee Added Successfully..");
		
		return "add_emp";
		
		
	}

}
