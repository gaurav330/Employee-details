package com.prog.repository;

public interface Emprepo extends JpaRepository<Employee, Integer>{

}
