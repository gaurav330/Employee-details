package com.prog.entity;

import javax.persistence.Entity;
import java.persistence.Table;

@Entity
@Table(name = "EMP_SYSTEM")

public class Employee {
	
	private int id;
	private String name;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", Email=" + Email + ", Dob=" + Dob + ", Age=" + Age
				+ ", salary=" + salary + "]";
	}
	private String Email;
	private String Dob;
	private int Age;
	private int salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getDob() {
		return Dob;
	}
	public void setDob(String dob) {
		Dob = dob;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}

}
