package com.prog.service;

@Service

public class Empservice {
	
	@Autowired
	
	private EmpRepo repo;
	
	public void addEmp(Employee e)
	
	{
		
		repo.save(e);
		
	}

}
